﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PROGPOE1.DAL;
using PROGPOE1.Models;
using PROGPOE1.Models.DBEntities;
using System.Security.Claims;

namespace PROGPOE1.Controllers
{
    [Authorize]
    public class EmployeeController : Controller
    {
        private readonly EmployeeDbContext _context;

        public EmployeeController(EmployeeDbContext context)
        {
            _context = context;
        }
        [HttpGet]
        public IActionResult Edit(int id)
        {
            var employee = _context.Employees.Find(id);
            if (employee == null)
            {
                TempData["errorMessage"] = $"Employee with id {id} not found.";
                return RedirectToAction("Index");
            }

            var model = new EmployeeViewModel
            {
                Id = employee.Id,
                FirstName = employee.FirstName,
                LastName = employee.LastName,
                DateOfBirth = employee.DateOfBirth,
                Email = employee.Email,
                HourlyRate = employee.HourlyRate,
                HoursWorked = employee.HoursWorked,
                Salary = employee.Salary,
                Status = employee.Status  // Include Status
            };

            return View(model);
        }

        [HttpPost]
        public IActionResult Edit(EmployeeViewModel model)
        {
            try
            {
                // Remove Status and FileUpload from ModelState since they're not required for editing
                ModelState.Remove("Status");
                ModelState.Remove("FileUpload");

                if (!ModelState.IsValid)
                {
                    var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage);
                    TempData["errorMessage"] = "Validation failed: " + string.Join(", ", errors);
                    return View(model);
                }

                var employee = _context.Employees.Find(model.Id);
                if (employee == null)
                {
                    TempData["errorMessage"] = "Employee not found.";
                    return RedirectToAction("Index");
                }

                employee.FirstName = model.FirstName;
                employee.LastName = model.LastName;
                employee.DateOfBirth = model.DateOfBirth;
                employee.Email = model.Email;
                employee.HourlyRate = model.HourlyRate;
                employee.HoursWorked = model.HoursWorked;
                employee.Salary = model.HoursWorked * model.HourlyRate;  // Recalculate salary

                // Don't update the Status - keep the existing one
                // employee.Status = model.Status;

                _context.Update(employee);
                _context.SaveChanges();

                TempData["successMessage"] = "Employee details updated successfully";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                TempData["errorMessage"] = "Error updating employee: " + ex.Message;
                return View(model);
            }
        }


        [HttpGet]
        public IActionResult Index()
        {
            var userRole = User.FindFirst(ClaimTypes.Role)?.Value;

            if (userRole == "Lecturer")
            {
                return RedirectToAction("Create");
            }

            var employeeList = _context.Employees
                .Select(employee => new EmployeeViewModel
                {
                    Id = employee.Id,
                    FirstName = employee.FirstName,
                    LastName = employee.LastName,
                    DateOfBirth = employee.DateOfBirth,
                    Email = employee.Email,
                    HoursWorked = employee.HoursWorked,
                    HourlyRate = employee.HourlyRate,
                    Salary = employee.Salary,
                    Status = employee.Status
                })
                .ToList();

            return View(employeeList);
        }

        [HttpGet]
        public IActionResult Create() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(EmployeeViewModel employeeData)
        {
            if (!ModelState.IsValid)
            {
                return View(employeeData);
            }

            try
            {
                var employee = new Employee
                {
                    FirstName = employeeData.FirstName ?? "Unknown",
                    LastName = employeeData.LastName ?? "Unknown",
                    DateOfBirth = employeeData.DateOfBirth == default ? DateTime.Now : employeeData.DateOfBirth,
                    Email = string.IsNullOrWhiteSpace(employeeData.Email) ? "unknown@example.com" : employeeData.Email,
                    HoursWorked = Math.Max(0, employeeData.HoursWorked),
                    HourlyRate = Math.Max(0, employeeData.HourlyRate),
                    Salary = (employeeData.HoursWorked > 0 && employeeData.HourlyRate > 0)
                        ? employeeData.HoursWorked * employeeData.HourlyRate
                        : 0,
                    Status = "Pending"
                };

                _context.Employees.Add(employee);
                _context.SaveChanges();

                TempData["successMessage"] = "Employee created successfully!";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                TempData["errorMessage"] = $"Error creating employee: {ex.Message}";
                return View(employeeData);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Accept(int id)
        {
            var employee = _context.Employees.Find(id);
            if (employee == null)
            {
                TempData["errorMessage"] = "Employee not found.";
                return RedirectToAction("Index");
            }

            employee.Status = "Accepted";
            _context.SaveChanges();

            TempData["successMessage"] = $"Employee {employee.FirstName} {employee.LastName} has been accepted.";
            return RedirectToAction("Index");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Reject(int id)
        {
            var employee = _context.Employees.Find(id);
            if (employee == null)
            {
                TempData["errorMessage"] = "Employee not found.";
                return RedirectToAction("Index");
            }

            employee.Status = "Rejected";
            _context.SaveChanges();

            TempData["successMessage"] = $"Employee {employee.FirstName} {employee.LastName} has been rejected.";
            return RedirectToAction("Index");
        }
    }
}